function parsave(fname, history)
save(fname, 'history')
end