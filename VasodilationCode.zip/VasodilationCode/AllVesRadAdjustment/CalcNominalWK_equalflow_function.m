function [R1, R2, CT] = CalcNominalWK_equalflow_function(RadSc,t, Pdat, Qdat)

rad = [0.047, 0.026, 0.037, 0.024, 0.013, 0.032, 0.017, 0.023, ...
    0.017, 0.020, 0.016, 0.015, 0.014, 0.026, 0.019, 0.025, 0.015, 0.024, ...
    0.015, 0.022, 0.018]; % radii going from vessel 1 to 21

lgt = [0.410, 0.445, 0.372, 0.241, 0.052, 0.202, 0.212, 0.311, ...
    0.177, 0.262, 0.069, 0.140, 0.062, 0.081, 0.184, 0.083, 0.302, ...
    0.469, 0.177, 0.178, 0.055]; % length going from vessel 1 to 21

% RadSc is the scaling param for the radii that we infer 
% (common to all vessels for now)
% For vasodilation, RadSc > 1

rad = rad .* RadSc;

num_vessels = size(lgt,2);

% P_spread= mean(Pdat); % gives results closer to the hard-coded values in sor06 
% % than the formula below, but obviously is not realistic if time series not
% % available
Psys = max(Pdat); Pdia = min(Pdat); Pmean = (Psys+2*Pdia)/3;
PdatStats = [Psys, Pmean, Pdia];
P_spread = PdatStats(2);

[tau] = TimeConstant_static(PdatStats,Qdat,t);

%tau = 0.1;

% Nondimensional all constants
Q_spread = mean(Qdat);
cf = 1332.22;                % Conversion factor from mmHg to g/cm/s^2
g = 981;                     % Gravitational constant (g/cm^2)
ratio = 0.2;                 % Windkessel Ratio (R1/RT) when not using Zc impedance
rho = 1.055;                 % Density of blood, assumed constant (g/cm^3)
Lr = 0.1;                    % Nondimensional length
qc = 10*Lr^2;                % Nondimensional flow
Pnd = P_spread*(cf/rho/g/Lr);% Nondimensional mean pressure
Qnd = Q_spread/qc;           % Nondimensional mean flow
tc = tau*qc/Lr^3;            % Nondimensional tau parameter for WK

% Flow in every vessel computed accordinf to Poiseulle relation
Q = NaN(num_vessels,1);

% To calculate the nominal Windkessel resistance values, we follow a
% Poiseuille relationship. More on this can be found in publications by
% Colebank, Qureshi, and Olufsen (2018-2019)
r4l = (rad.^4)./lgt; r4l = r4l';% vector with num_vessels elements
% distribute flow according to Poiseuille relation
FlowCalc = @(Q,p,d1,d2) Q(p) * 0.5; % calculated for d1
% to calculate for d2, call the function as @(p,d2,d1)

Q(1) = Qnd; % mean flow in MPA

% index of parents in the order they appear in the tree (see fig 2 in Qureshi 2018)
parents = [1,2,3,4,8,10,6,14,16,18]; 

for i=2:2:num_vessels-1
    
    d1index = i; d2index = i+1; pindex = parents(i/2);
    
    Q(d1index) = FlowCalc(Q,pindex,d1index,d2index);
    Q(d2index) = FlowCalc(Q,pindex,d2index,d1index);
    
end

% Here, we calculate RT = P/Q, and distribute the resistance. Note that we
% set a 20/80 rule for R1/R2.

% index for the terminal vessels in the order they appear in the tree
TerminalVessels = [5,7,9,11,12,13,15,17,19,20,21];

Rtotal  = NaN(size(TerminalVessels,2),1);
R1      = NaN(size(TerminalVessels,2),1);
R2      = NaN(size(TerminalVessels,2),1);
CT      = NaN(size(TerminalVessels,2),1);

for i=1:size(TerminalVessels,2)
    Rtotal(i) = Pnd./Q(TerminalVessels(i));
    R1(i) = round(ratio.*Rtotal(i),4);
    R2(i) = round(Rtotal(i)-R1(i),4);
    CT(i) = tc./Rtotal(i);
end

end

