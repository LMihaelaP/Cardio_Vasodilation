nv = 21; % total no of vessels
ntp = 512; % no of time points
Rves = NaN(nv,1); % contains the total resistance calculated for every vessel individually
for i=1:nv
    % or find flow based on Poiseuille flow
    Rves(i) = mean(trueHealthyPressure(1:ntp))/mean(trueHealthyFlow(1:ntp));
end

R_parallel = @(Rv1, Rv2) (1/Rv1 + 1/Rv2)^(-1);
R_series = @(Rv1, Rv2) Rv1 + Rv2;

PL = [3,6,14,16,18]; % all parents in the left branch
TVL = [7,15,17,19,20,21]; % all terminal vessels in the left branch

PR = [2,4,8,10]; % all parents in the right branch
TVR = [5,9,11,12,13]; % all terminal vessels in the right branch

% calculate total resistance for the left branch
X_left = R_series(Rves(PL(end), R_parallel(Rves(TVL(end)), Rves(TVL(end-1)))));

for i = size(PL,1)-1:(-1):1
    X_left = R_series(Rves(PL(i)), R_parallel(X_left, Rves(TVL(i))));
end

% calculate total resistance for the right branch
X_right = R_series(Rves(PR(end), R_parallel(Rves(TVR(end)), Rves(TVR(end-1)))));

for i = size(PR,1)-1:(-1):1
    X_right = R_series(Rves(PR(i)), R_parallel(X_right, Rves(TVR(i))));
end

RTsystem = R_series(Rves(1), R_parallel(X_left, X_right));