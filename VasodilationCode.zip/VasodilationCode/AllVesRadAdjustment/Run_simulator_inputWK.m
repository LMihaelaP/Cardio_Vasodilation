function [ObjFct, pass, Z, C, L, flow] = Run_simulator(x, extra_p, ...
    trueFlow, sc, gp_ind, corrErr, t, Pdat, Qdat)

ntp = size(trueFlow,1); % number of time points

f3_vec = x(:,1) * sc(1);
rr1_vec = x(:,2) * sc(2);
rr2_vec = x(:,3) * sc(3);
cc1_vec = x(:,4) * sc(4);
RadSc_vec = x(:,5) * sc(5);

n = size(x,1);

id = extra_p(1); cycles = extra_p(3); max_cycles = extra_p(4);

pass = NaN(n,1);
NLL = NaN(n,1); Z = NaN(ntp,n);

for i = 1:n
    
    [R1, R2, CT] = CalcNominalWK_function(RadSc_vec(i),t, Pdat, Qdat);

%     R1 = [510.4072231, 388.0002164, 538.8259481, 466.9618518, 1807.757766, ...
%         1173.676967, 266.0796751, 1041.232548, 107.1125395, 116.974148, 83.43084455]; R1=R1';
%     
%     R2 = [2041.628892, 1552.000866, 2155.303792, 1867.847407, 7231.031065, ...
%         4694.70787, 1064.3187, 4164.930191, 428.4501579, 467.896592, 333.7233782]; R2=R2';
%     
%     CT = [0.005254628, 0.006912367, 0.004977489, 0.00574351, 0.001483606, 0.002389967, ...
%      0.01054214, 0.00269397, 0.026187868, 0.023980077, 0.033621248]; CT=CT';
    
    param = [f3_vec(i), rr1_vec(i), rr2_vec(i), cc1_vec(i), RadSc_vec(i),...
        R1',R2',CT', cycles, max_cycles, id];
    
    param_str = mat2str(param);
    
    cx = unix(sprintf('./sor06  %s',param_str(2:end-1)));
    
    if cx == 0
        
        pass(i) = 1;
        
        state = CreateData_Optim(id);
        flow = state(1:end/2);
        
        NLL(i) = sum((flow-trueFlow).^2);
        Z(:,i) = trueFlow - flow;
        
    else
        
        pass(i) = 0;
        NLL(i) = 1e+10; % very large value for unsuccessful simulation
        
    end
end

ObjFct = NLL; C = NaN; L = NaN;


end

