clear; close all;

% Add path to GPstuff toolbox
GPpath = genpath('GPstuff-4.7'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path
addpath('MCMC_run')

%% Set useful parameters
% Generic
nd = 5; % no of parameters
cycles = 1; max_cycles = 30;
ntp = 512;
t = linspace(0,0.11,ntp); t = t';
gp_ind = NaN;
em_ind = 0;
corrErr = 0;
nv = 21;%3; % no of vessels
GP_hyperHyper = NaN(6, 1);
% ranges for [stiff, r1, r2, c, radSc]
l = [2e04, 0.05, 0.05, 0.05, 1]; % if stiffness increases, resistance is also expected to increase
u = [1e06, 4,  4,  2.5, 2.5];
sc = max(abs(l),abs(u));

% Specific
id = 10; % id for data files
extra_p = [id, nd, cycles, max_cycles];

%% Load the data

Pdat = load('pC6_512.dat'); truePressure = Pdat;
Qdat = load('qC6_512.dat'); trueFlow = Qdat;

%% Analysis
% Take stiffness and radius scaling factor from a Sobol sequence
% to construct GP model out of D = 100 simulator callings

X = sobolset(2, 'Skip',1.4e4,'Leap',0.9e14); % draw 100 points

f3_vec = l(1) + (u(1)-l(1)) * X(:,1);
RadSc_vec = l(end) + (u(end)-l(end)) * X(:,2);

par_fixedOptim = [f3_vec, RadSc_vec];%./[sc(1), sc(end)];

% Now run optimisation to estimate r1, r2, c for every f3 and RadSc
nstarts = 10; % 10 initial values for the optimisation algorithm

Y = sobolset(3, 'Skip',1.4e4,'Leap',0.95e15); % draw 10 points

r1_vec = l(2) + (u(2)-l(2)) * Y(:,1);
r2_vec = l(3) + (u(3)-l(3)) * Y(:,2);
c_vec = l(4) + (u(4)-l(4)) * Y(:,3);

param0 = [r1_vec, r2_vec, c_vec]./sc(2:end-1);

% Run the 100 optimisations in parallel (every 20 or 40)
delete(gcp('nocreate'))
parpool('local', 40)

parfor i=1:size(par_fixedOptim,1)
    % Re-estimate nominal R01, R02, CT0
    [R1_0, R2_0, CT_0] = CalcNominalWK_function(RadSc_vec(i),t, Pdat, Qdat);
    
for j = 1:nstarts
    id = i;
    extra_p = [id, cycles, max_cycles];
    history{i}(j) = GradientAlgorithm(param0(j,:), par_fixedOptim(i,:), ...
        R1_0, R2_0, CT_0, extra_p, sc(2:end-1), l(2:end-1)./sc(2:end-1), ...
        u(2:end-1)./sc(2:end-1), truePressure);
end

end

load('HistoryOptimisation.mat')

% Now extract the optimised r1, r2, c values, and compute the corresponding 
% nominal R1_0, R2_0 and CT_0
for i=1:size(par_fixedOptim,1)
    % Check if we have multimodality
    for j=1:nstarts
        par_starts_optimised(i,j,:) = history{i}(j).x(end,:);
        rss_starts_optimised(i,j) = history{i}(j).fval(end);
    end
    
    % find minimum across all initial values
    [Optim_RSS(i), I_minRss(i)] = min(rss_starts_optimised(i,:)); 
    %
    Optim_r1r2c(i,:) = [par_starts_optimised(i,I_minRss(i),1),par_starts_optimised(i,I_minRss(i),2),par_starts_optimised(i,I_minRss(i),3)];

    % Estimate corresponding nominal R01, R02, CT0
    [R1_0optim(i,:), R2_0optim(i,:), CT_0optim(i,:)] = CalcNominalWK_function(RadSc_vec(i),t, Pdat, Qdat);
end

% Now build emulator with training points: x = par_fixedOptim and y = (R1,
% R2, CT) for e.g. 2 terminal vessels, and another emulator for y =
% (r1,r2,c), and another emulator for y = (rss)

% find and remove points for which rss optim is 10^10 (if any)
% ...

x = par_fixedOptim./[sc(1), sc(end)]; % bring x to the same magnitude

k=1; y(1,:) = R1_0optim(:,k); y(2,:) = R2_0optim(:,k); y(3,:) = CT_0optim(:,k); % 3 emulators for WK for first terminal vessel
k=11; y(4,:) = R1_0optim(:,k); y(5,:) = R2_0optim(:,k); y(6,:) = CT_0optim(:,k); % WK for last terminal vessel

y(7:9,:) = Optim_r1r2c'; % 3 emulators for WK adjustments r1, r2, c

y(10,:) = Optim_RSS; % one emulator for optimum rss values

% standardise each y
for i=1:size(y,1)
    mean_y(i) = mean(y(i,:)); std_y(i) = std(y(i,:));
    y(i,:) = (y(i,:)-mean_y(i))./std_y(i);
end

% build 10 emulators now for every y(i,:)
H_r = [10 1 1 0.00001];

for i=1:size(y,1)
    gp{i} = GPmodel(x,(y(i,:))', H_r);

    [w,s] = gp_pak(gp{i});
    disp(exp(w))
    
    % Make predictions using the gp, will need to also do on unseen data
    E = gp_pred(gp{i}, x, (y(i,:))', x);
    figure(i); clf(i); plot((y(i,:))', E, '.');
    hold on; plot((y(i,:))',(y(i,:))','-r')
    xlabel('Train data'); ylabel('Predictions')
    
end

% now plot emulated surface
% x is 2d: stiffness and radius scaling and y is 1) r1, 2) r2, 3) c, 4) rss
close all

n = 100;

x_test(1,:) = linspace(l(1),u(1),n);
x_test(2,:) = linspace(l(end),u(end),n);

par = NaN(n^2,2);
next = 0;
for i=1:n
    for j=1:n
        next = next+1;
        par(next,:) = [x_test(1,i) x_test(2,j)]./[sc(1) sc(end)];
    end
end

for i=7:size(y,1)
    E = gp_pred(gp{i}, x, (y(i,:))', par);
    figure(i);clf(i)
    E = reshape(E,n,n);
    [xx1,xx2] = meshgrid(x_test(1,:)./sc(1),x_test(2,:)./sc(end));
    xx1 = xx1'; xx2 = xx2'; % transpose to match construction z
    zz = griddata(x_test(1,:)./sc(1),x_test(2,:)./sc(end),E,xx1,xx2,'linear');
    contourf(xx1.*sc(1),xx2.*sc(end),zz.*std_y(i)+mean_y(i),50);
    colorbar
end

exit;