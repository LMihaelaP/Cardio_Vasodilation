function history = GradientAlgorithm(param0, par_fixedOptim, R1_0, R2_0, CT_0, ...
    extra_p, sc, l, u, truePressure)

% Set up shared variables with OUTFUN
history.x = [];
history.fval = [];

%% Contrained optimization with gradient based method (interior point algorithm)
options=optimoptions('fmincon', 'Display','iter', 'Algorithm','sqp', ...
    'OutputFcn',@outfun, ...
    'StepTolerance',  1.0000e-11, 'OptimalityTolerance', 1.0000e-7, ...
    'ConstraintTolerance', 1.0000e-7, 'FiniteDifferenceType', 'central',...
    'MaxFunctionEvaluations', 3000, 'MaxIterations', 2000);

[x,fval] = fmincon(@(x)L2norm(truePressure, x, par_fixedOptim, ...
    R1_0, R2_0, CT_0, extra_p, sc), ...
    param0, [], [], [], [], l, u, [], options);

    function stop = outfun(x,optimValues,state)
        stop = false;
        
        switch state
            case 'init'
                hold on
            case 'iter'
                % Concatenate current point and objective function value with history
                % x must be a row vector
                history.fval = [history.fval; optimValues.fval];
                history.x = [history.x; x];
            case 'done'
                hold off
            otherwise
        end
    end

    function NLL = L2norm(truePressure, param, par_fixedOptim, ...
            R1_0, R2_0, CT_0, extra_p, sc)
        
        f3 = par_fixedOptim(1); RadSc = par_fixedOptim(2);
        
        id = extra_p(1); cycles = extra_p(2); max_cycles = extra_p(3);
        
        param_AllInput = [f3, param.*sc, RadSc, R1_0',R2_0',CT_0', cycles, max_cycles, id];
        
        param_str = mat2str(param_AllInput);
        
        cx = unix(sprintf('./sor06  %s',param_str(2:end-1)));
        
        if cx == 0
            
            pressure = CreateData_Optim(id);
            
            NLL = sum((pressure-truePressure).^2);
            
        else
            
            NLL = 1e+10; % very large value for unsuccessful simulation
            
        end
        
    end
end