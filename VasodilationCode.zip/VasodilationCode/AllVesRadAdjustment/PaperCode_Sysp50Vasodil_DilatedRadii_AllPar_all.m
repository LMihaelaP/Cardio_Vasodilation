% Script to run MCMC for vasodilation of all vessels 
clear; close all;

% Add path to MCMC toolbox
addpath('MCMC_run')

%% Set useful parameters
% Generic
nd = 5; % no of parameters
cycles = 1; max_cycles = 30;
ntp = 512;
t = linspace(0,0.11,ntp); t = t';
gp_ind = NaN;
em_ind = 0;
corrErr = 0;
nv = 21;%3; % no of vessels
GP_hyperHyper = NaN(6, 1);
% ranges for [stiff, r1, r2, c, radSc]
l = [2e04, 0.05, 0.05, 0.05, 1]; % if stiffness increases, resistance is also expected to increase
u = [1e07, 5,  5,  2.5, 3];
sc = max(abs(l),abs(u));
alp = [1 1 1 1 1]; % priors
bet = [1 1 1 1 1];

% Specific
id = 10; % id for data files
extra_p = [id, nd, cycles, max_cycles];

%% Generate the data

niter = 30;
% algorithm does not converge
%par_true = [2.5e+05, 1, 1.5, 0.8, 1.5]; % [stiff, r1, r2, c, RadSc]
%par_true = [51700, 0.21, 0.88, 1.44, 1.5]; % [stiff, r1, r2, c, RadSc]
%par_true = [1e+05, 0.5, 1.2, 1, 1.5]; % [stiff, r1, r2, c, RadSc]

par_true = [8e+05, 1, 1, 1, 1.5];

R1(1,:) = [465.4, 383.5, 539.8, 465.1, 1962.8, 1145.5, 261.0, 952.6, ...
    117.9, 116.8, 80.5];
R2(1,:) = [1861.7, 1534.2, 2159.2, 1860.3, 7851.1, 4581.9, 1043.9, 3810.4,...
    471.4, 467.0, 322.0];

% tau = 0.1;
% 
% CT(1,:) = tau./(R1(1,:)+R2(1,:));

CT(1,:) = [0.0058, 0.0070, 0.0050, 0.0058, 0.0014, 0.0023, 0.0103, 0.0028, ...
    0.0228, 0.0230, 0.0334];

cleanHealthyPressure = cell(niter,1);
cleanHealthyFlow = cell(niter,1);

% index for the terminal vessels in the order they appear in the tree
TerminalVessels = [5,7,9,11,12,13,15,17,19,20,21];

ntermVessels = size(TerminalVessels,2);

% rad = [0.047, 0.026, 0.037, 0.024, 0.013, 0.032, 0.017, 0.023, ...
%     0.017, 0.020, 0.016, 0.015, 0.014, 0.026, 0.019, 0.025, 0.015, 0.024, ...
%     0.015, 0.022, 0.018]; % radii going from vessel 1 to 21
% 
% Zc = get_Zc(par_true(1),rad(TerminalVessels));
% R1 = Zc;

for j=1:niter
    
     param = [par_true, R1(j,:),R2(j,:),CT(j,:), cycles, max_cycles, id];
%       param = [par_true, R1',R2(j,:),CT(j,:), cycles, max_cycles, id];

    param_str = mat2str(param);
    
    % Calling PDEs Solver (C++)
    cx = unix(sprintf('./sor06  %s',param_str(2:end-1)));
    
    if cx == 0
        for i=1:nv % loop over vessels
            pu = load(sprintf('pu%d_%d.2d', i, id));
            [~,~,p,q,~,~] = gnuplot(pu);
            if any(i==TerminalVessels)
                cleanHealthyPressure{j}(ntp*(i-1)+1:ntp*i) = p(:,end);% floor(end/2)); % clean, noiseless pressure
                cleanHealthyFlow{j}(ntp*(i-1)+1:ntp*i) = q(:,end);% floor(end/2)); % clean, noiseless flow
            else
                cleanHealthyPressure{j}(ntp*(i-1)+1:ntp*i) = p(:,1);% floor(end/2)); % clean, noiseless pressure
                cleanHealthyFlow{j}(ntp*(i-1)+1:ntp*i) = q(:,1);% floor(end/2)); % clean, noiseless flow
            end
            
            %cleanHealthyPressure{j}(ntp*(i-1)+1:ntp*i) = p(:,1);%floor(end/2)); % clean, noiseless pressure
            %cleanHealthyFlow{j}(ntp*(i-1)+1:ntp*i) = q(:,1);%floor(end/2)); % clean, noiseless flow
        end
        
    else
        disp('..... Choose different parameter values .....')
    end
    
    Pdat = cleanHealthyPressure{j}(1:ntp); Pdat = Pdat'; % in MPA
    Qdat = cleanHealthyFlow{j}(1:ntp); Qdat = Qdat'; % in MPA
    
%     % calculates the flow with Poiseuille relation (assuming MPA mean
%     pressure in RT), and that R1 and R2 both depend on data p and q
     [R1(j+1,:), R2(j+1,:), CT(j+1,:)] = CalcNominalWK_function(par_true(end),t, Pdat, Qdat);
    
% % OR
% %     calculates the flow with Poiseuille relation (assuming MPA mean
% %     pressure in RT), and that R1 = charcateristic impedance and and R2 depends on data p and q
% [~,~,CT(j+1,:), RT(j+1,:)] = CalcNominalWK_function(par_true(end),t, Pdat, Qdat);
% 
% R2(j+1,:) = RT(j+1,:)-R1';

    % OR
    
    % takes the flow from model predictions
    
%     cf = 1332.22;                % Conversion factor from mmHg to g/cm/s^2
%     g = 981;                     % Gravitational constant (g/cm^2)
%     ratio = 0.2;                 % Windkessel Ratio (R1/RT) when not using Zc impedance
%     rho = 1.055;                 % Density of blood, assumed constant (g/cm^3)
%     Lr = 0.1;                    % Nondimensional length
%     qc = 10*Lr^2;                % Nondimensional flow
    
    %
%         Psys = max(Pdat); Pdia = min(Pdat); Pmean = (Psys+2*Pdia)/3;
%         PdatStats = [Psys, Pmean, Pdia];
%         [tau] = TimeConstant_static(PdatStats,Qdat,t);
%         tc = tau*qc/Lr^3;            % Nondimensional tau parameter for WK
%          
%     for k=1:ntermVessels
%         Pnd = mean(Pdat)*(cf/rho/g/Lr);% Nondimensional mean pressure
% %         PCnd = (mean(cleanHealthyPressure{j}(1:ntp))-mean(cleanHealthyPressure{j}((ntp*(TerminalVessels(k)-1)+1):(ntp*TerminalVessels(k)))))*(cf/rho/g/Lr);
% %        PCnd = (mean(cleanHealthyPressure{j}(1:ntp))-mean(cleanHealthyPressure{j}((ntp*(TerminalVessels(end)-1)+1):(ntp*TerminalVessels(end)))))*(cf/rho/g/Lr);      
% %PCnd = (mean(cleanHealthyPressure{j}((ntp*(TerminalVessels(k)-1)+1):(ntp*TerminalVessels(k)))))*(cf/rho/g/Lr);        
% Qnd = mean(cleanHealthyFlow{j}(ntp*(TerminalVessels(k)-1)+1:ntp*TerminalVessels(k)))/qc;           % Nondimensional mean flow
%         RT = Pnd/Qnd; %PCnd/Qnd;
%         R1(j+1,k) = ratio*RT; R2(j+1,k) = (1-ratio)*RT;
%         CT(j+1,k) = tc./RT;
%     end
j
end

figure(1);clf(1);for j=1:niter;hold on;plot(cleanHealthyPressure{j}(1:ntp));end;xlabel('Time'); ylabel('MPA pressure')
figure(2);clf(2);for j=1:niter;a(j)=mean(cleanHealthyPressure{j}(1:ntp));end;plot(1:niter,a);xlabel('Iteration no'); ylabel('mean MPA pressure')
figure(3);clf(3);k=11;for j=1:niter;hold on;plot(cleanHealthyPressure{j}((ntp*(TerminalVessels(k)-1)+1:ntp*TerminalVessels(k))));end;xlabel('Time'); ylabel('terminal vessel pressure')
figure(4); clf(4);k=11;for j=1:niter;a(j)=mean(cleanHealthyPressure{j}((ntp*(TerminalVessels(k)-1)+1:ntp*TerminalVessels(k))));end;plot(1:niter,a);xlabel('Iteration no'); ylabel('mean terminal vessel pressure')
figure(5);clf(5);k=11;for j=1:niter;hold on;plot(cleanHealthyFlow{j}((ntp*(TerminalVessels(k)-1)+1:ntp*TerminalVessels(k))));end;xlabel('Time'); ylabel('terminal vessel flow')
figure(6); clf(6);k=11;for j=1:niter;a(j)=mean(cleanHealthyFlow{j}((ntp*(TerminalVessels(k)-1)+1:ntp*TerminalVessels(k))));end;plot(1:niter,a);xlabel('Iteration no'); ylabel('mean terminal vessel flow')
figure(7); clf(7);k=11;subplot(1,3,1);plot(1:niter+1,R1(:,k));xlabel('Iteration no'); ylabel('R1 terminal vessel')
subplot(1,3,2);plot(1:niter+1,R2(:,k));xlabel('Iteration no'); ylabel('R2 terminal vessel');
subplot(1,3,3);plot(1:niter+1,CT(:,k));xlabel('Iteration no'); ylabel('C terminal vessel')

figure(1); clf(1)
i=1;plot(cleanHealthyPressure(ntp*(i-1)+1:ntp*i))

truePressure = cleanHealthyPressure; % will need to use noisy pressure
trueFlow = cleanHealthyFlow; % will need to use noisy flow for inference

Pdat = truePressure(1:end/nv); % to calculate nominal Windkessel parameter, use MPA data only
Qdat = trueFlow(1:end/nv); % from MPA

% But we only do the parameter inference on the flow data from the first 3 vessels

%% Run AM sampling

par_start =  [1e+05, 1, 1, 1, 1];

nSamples = 150000;
n_burnin = 1000;

adapt_int = 100; % adaptation interval
scale = 1; % scale the original paramerts bc of varying mgnitudes
% proposal covariance for MH within the trajectory
cov_MH = diag(repmat(5*10^(-8),nd,1));
R = chol(cov_MH);

gp_regr_refitted = NaN; x_regr_refitted= NaN; y_regr_refitted = NaN;
gp_class = NaN; x_class = NaN; y_class = NaN; extraPar_gp = NaN; phase_ind = NaN;

p_sample = NaN(nSamples+n_burnin, nd); % unbounded HMC samples
ObjFct_sample = NaN(nSamples+n_burnin,1); % log likelihood samples
%s2_sample = NaN(nSamples+n_burnin,1); % noise variance samples
p_sample(1,:) = par_start;

qcov_adjust = 1e-8; % epsilon adjustment for chain covariance
qcov_scale = 2.4 / sqrt(nd); % s_d from recursive covariance formula
acc = 0; % acceptance rate of the algorithm
rejout = 0; % rejection rate for being outside the range

ObjFct_sample(1) = mice_pulm_ss(p_sample(1,:),trueFlow,...
    gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
    gp_class, x_class, y_class, extraPar_gp, em_ind, phase_ind, extra_p, ...
    sc, gp_ind, corrErr, t, Pdat, Qdat);

%s2_sample(1) = ObjFct_sample(1)/(ntp-nd); % observation noise variance

oldObjFct = ObjFct_sample(1);

oldpar = p_sample(1,:)./sc;

oldprior = Prior_AM(oldpar,sc,l,u,gp_ind,alp,bet,GP_hyperHyper,corrErr);

covchain = []; meanchain = []; wsum = []; lasti = 0;

s2 = 1e-06;

for i=2:nSamples+n_burnin
    
    q = randn(1,nd);
    
    newpar = oldpar + q*R;
    
    if any(newpar.*sc<l) || any(newpar.*sc>u)        
        %disp('proposal outside boundaries')
        newObjFct = 10^10; % ss
        %newObjFct = -10^10; %loglik
        
        newprior = 0;
        
        rejout = rejout + 1;
        
    else % inside the boundaries
        
        [newObjFct,pass] = Run_simulator(newpar, extra_p, trueFlow, sc, ...
            gp_ind, corrErr, t, Pdat, Qdat);
        
        newprior = Prior_AM(newpar,sc,l,u,gp_ind,alp,bet,GP_hyperHyper,corrErr);
        
    end % inside/outside boundaries
    
    if newObjFct == 10^10 % outside boundaries
        tst = 0;
    else
        tst = exp(-0.5/s2*(newObjFct - oldObjFct) + newprior-oldprior); % for ss
        %tst = exp(newObjFct - oldObjFct + newprior-oldprior); % for loglik
    end
    
    %[newObjFct, oldObjFct]
    
    if tst <= 0
        accept = 0;
    elseif tst >= 1
        accept = 1; acc = acc + 1;
    elseif tst > rand(1,1)
        accept = 1; acc = acc + 1;
    else
        accept = 0;
    end
    
    if accept == 1 % accept proposal
        
        p_sample(i,:) = newpar.*sc;
                
        %disp('accept')
        
        oldpar = newpar;
        
        oldObjFct = newObjFct; ObjFct_sample(i) = newObjFct;
        
        oldprior = newprior;
        
    else % reject
        p_sample(i,:) = oldpar.*sc;
        
        %disp('reject')
        
        oldpar = oldpar;
        
        oldObjFct = oldObjFct; ObjFct_sample(i) = oldObjFct;
        
        oldprior = oldprior;
        
    end
    
    if mod(i, adapt_int) == 0 % we adapt
        %disp('we adapt')
        if scale == 1 % calculate the chain covariance for the transformed parameters
            [covchain,meanchain,wsum] = covupd(p_sample((lasti+1):i,1:nd)./sc,1, ...
                covchain,meanchain,wsum);
        else
            [covchain,meanchain,wsum] = covupd(p_sample((lasti+1):i,1:nd),1, ...
                covchain,meanchain,wsum);
        end
        
        upcov = covchain; % update covariance based on past samples
        
        [Ra,p] = chol(upcov);
        if p % singular
            % try to blow it
            [Ra,p] = chol(upcov + eye(nd)*qcov_adjust);
            if p == 0 % choleski decomposition worked
                % scale R
                R = Ra * qcov_scale;
            end
        else
            R = Ra * qcov_scale;
        end
        
        lasti = i;
        
    end
    
    %s2_sample(i) = 1/gamrnd(a_noisevar+0.5*ntp, 1/(b_noisevar+0.5*ObjFct_sample(i)));

    if mod(i,100) == 0
        save('AMsimulator_Vasodil_DilatedRadii_AllPar.mat');
    end
    
end

exit;