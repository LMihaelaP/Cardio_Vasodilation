%% Set useful parameters
% Generic
nd = 1; % no of parameters
cycles = 1; max_cycles = 30;
ntp = 512;
t = linspace(0,0.11,ntp); t = t';
gp_ind = NaN;
em_ind = 0;
corrErr = 0;
nv = 21;%3; % no of vessels


% Specific
id = 10; % id for data files
extra_p = [id, nd, cycles, max_cycles];

%% Generate the data

niter = 20;

% MJC: set scaling to 1.0
par_true = [8e+04, 1.0, 1.0, 1.0, 1.0]; % [stiff, r1, r2, c, RadSc]
P_cap = 2.0;


cleanHealthyPressure = cell(niter,21);
cleanHealthyFlow = cell(niter,21);

% index for the terminal vessels in the order they appear in the tree
TerminalVessels = [5,7,9,11,12,13,15,17,19,20,21];

ntermVessels = size(TerminalVessels,2);


% Calculate terminal impedance
rad = [0.047, 0.026, 0.037, 0.024, 0.013, 0.032, 0.017, 0.023, ...
    0.017, 0.020, 0.016, 0.015, 0.014, 0.026, 0.019, 0.025, 0.015, 0.024, ...
    0.015, 0.022, 0.018]; % radii going from vessel 1 to 21


pdat = load('pC6_512.dat');
qdat = load('qC6_512.dat');
t = linspace(0,0.11,512);
[R1, R2, CT] = CalcNominalWK_function(par_true(end),t, pdat, qdat);
% [R1, R2, CT] = CalcNominalWK_equalflow_function(par_true(end),t, pdat, qdat);


% This will calculate the characteristic impedance and set it as the
% proximal resistance, R1. The distal resistance is then the remaining
% resistance, i.e. R2 = RT-R1.
Zc = get_Zc(par_true(1),rad(TerminalVessels));
RT = R1+R2;
R1 = Zc;
R2 = RT-Zc;

Qnd_test = zeros(niter,ntermVessels);
Pnd_test = zeros(niter,ntermVessels);

    
    param = [par_true, R1',R2',CT', cycles, max_cycles, id];
    
    param_str = mat2str(param);
    
    % Calling PDEs Solver (C++)
    cx = unix(sprintf('./sor06  %s',param_str(2:end-1)));
    %%
    if cx == 0
        for i=[1 TerminalVessels]%1:nv % loop over vessels
            pu = load(sprintf('pu%d_%d.2d', i, id));
            [~,~,p,q,~,~] = gnuplot(pu);
            % MJC
            cleanHealthyPressure{i} = p(:,[1 floor(end/2) end]); % clean, noiseless pressure
            cleanHealthyFlow{i} = q(:,[1 floor(end/2) end]); % clean, noiseless flow
            figure(100+i); hold on; plot(p(:,end));
            figure(1000+i); hold on; plot(q(:,end));
        end
        
    else
        disp('..... Choose different parameter values .....')
    end
 