% Function at will output the characteristic impedance of the vessel.

function Zc_ND = get_Zc(stiff,r)
g = 981.0;
Lr = 0.1;
rho = 1.055;
conv = 1333.22;
qc = 10*Lr^2; 
% r = r./Lr;

A = pi.*r.^2;
if isa(stiff,'function_handle')
    c0 = sqrt(stiff(r)./(2.*rho));
else
    c0 = sqrt(stiff./(2.*rho));
end
Zc = (rho./A).*c0;
Zc_ND = Zc'.*qc./rho/g/Lr;
end