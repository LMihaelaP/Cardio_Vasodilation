% This function will take the static pressure and dynamic flow data and
% estimate the Tau parameter. This considers two different scenarios, one
% where the capillary pressure is zero (tau1) and one where the capillary
% pressure is nonzero (tau2). For the time being, we only use tau1 in the
% code.
%
% Originally written by M. Umar Qureshi
% Modified by MJ Colebank.
function [tau] = TimeConstant_static(p,q,t)

% global p q N t t0 p0 tdia pdia nc n;
N = length(t);

dq = diff(q);
dt = diff(t);
dqdt = dq./dt;
nc = 3; n=0.0;%NOT SURE WHY: UMAR SET THIS

m = floor((N-1)/nc);
id = find(dqdt==0);

for i = 1:length(id)
    idtest = id(i);
    if(idtest > m)
        id1(i)=idtest;
    else
    end
end

id1 = id1(id1~=0);
ids = id1(1)-n;

% Try to fit the exponential between the mean pressure and the diastolic
% value
pdia = p(2:3);
tdia = t([ids(1) end]); tdia = tdia';

t0 = tdia(1);
p0 = pdia(1);

%% Define the two different exponentials

tau_opt1 = @(x) sum((pdia - (p0*exp(-(tdia-t0)/x))).^2);
%tau_opt2 = @(x) sum((pdia - (x(2)+(p0-x(2))*exp(-(tdia-t0)/x(1)))).^2);


%%
options = optimset('MaxFunEvals',1e8,'TolX',1e-8,'MaxIter',15000);

x0 = 0.1;
[xopt1,~,~,~] = fminsearch(tau_opt1,x0,options);
%myfit1 = p0*exp(-(t-t0)/xopt1);

% x0 = [0.1 0];
% [xopt2,~,~,~] = fminsearch(tau_opt2,x0,options);
% myfit2 = xopt2(2)+(p0-xopt2(2))*exp(-(t-t0)/xopt2(1));
% 
% figure; clf;
% plot(tdia,pdia,'-r',t,myfit1,'-k',t,myfit2,'--c');hold on;plot(t0,p0,'ob');
% % plot(t,min(p)+(max(p)-min(p))*(q-min(q))/(max(q)-min(q)),'b');
% line([t0 t0],[5 p0],'LineStyle','--','Color',[0 0 0]);
% set(gca,'ylim',[5 20]);

tau = xopt1;
%tau2 = xopt2(1);
end