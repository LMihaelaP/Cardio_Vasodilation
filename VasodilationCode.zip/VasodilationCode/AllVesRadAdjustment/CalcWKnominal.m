clear; close all;

rad = [0.047, 0.026, 0.037, 0.024, 0.013, 0.032, 0.017, 0.023, ...
    0.017, 0.020, 0.016, 0.015, 0.014, 0.026, 0.019, 0.025, 0.015, 0.024, ...
    0.015, 0.022, 0.018]; % radii going from vessel 1 to 21

lgt = [0.410, 0.445, 0.372, 0.241, 0.052, 0.202, 0.212, 0.311, ...
    0.177, 0.262, 0.069, 0.140, 0.062, 0.081, 0.184, 0.083, 0.302, ...
    0.469, 0.177, 0.178, 0.055]; % length going from vessel 1 to 21

% RadSc is the scaling param for the radii that we infer 
% (common to all vessels for now)
% For vasodilation, RadSc > 1

RadSc = 1; % changes in the inference process

rad = rad .* RadSc;

num_vessels = size(lgt,2);

%% Perform a nondimensionalization on all the input parameters
% To calculate nondimensional mean pressure and tau parameter, we need to
% consider the two different scenarios when 1) we have dynamic pressure
% data, or 2) we have only static values.

Qdat = load('qC6_512.dat'); % load the flow profile
Pdat = load('pC6_512.dat'); % load the pressure profile

ntp = 512; % 512 time points

t = linspace(0,0.11,ntp); % time vector

% from pressure time series, gives closer results to hard-coded values in
% sor06
P_spread = mean(Pdat);
[tau,~] = TimeConstant_timeseries(Pdat,Qdat,t);
 
% P_spread= mean(Pdat); % gives results closer to the hard-coded values in sor06 
% % than the formula below, but obviously is not realistic if time series not
% % available
% Psys = max(Pdat); Pdia = min(Pdat); %Pmean = (Psys+2*Pdia)/3;
% PdatStats = [Psys, P_spread, Pdia];%
% %PdatStats = [Psys, Pmean, Pdia];
% %P_spread = PdatStats(2);
% [tau,~] = TimeConstant_static(PdatStats,Qdat,t);

% Nondimensional all constants
Q_spread = mean(Qdat);
cf = 1332.22;                % Conversion factor from mmHg to g/cm/s^2
g = 981;                     % Gravitational constant (g/cm^2)
ratio = 0.2;                 % Windkessel Ratio (R1/RT) when not using Zc impedance
rho = 1.055;                 % Density of blood, assumed constant (g/cm^3)
Lr = 0.1;                    % Nondimensional length
qc = 10*Lr^2;                % Nondimensional flow
Pnd = P_spread*(cf/rho/g/Lr);% Nondimensional mean pressure
Qnd = Q_spread/qc;           % Nondimensional mean flow
tc = tau*qc/Lr^3;            % Nondimensional tau parameter for WK


Q = NaN(num_vessels,1);

% To calculate the nominal Windkessel resistance values, we follow a
% Poiseuille relationship. More on this can be found in publications by
% Colebank, Qureshi, and Olufsen (2018-2019)
r4l = (rad.^4)./lgt; r4l = r4l';% vector with num_vessels elements
% distribute flow according to Poiseuille relation
FlowCalc = @(Q,p,d1,d2) Q(p) * (r4l(d1)/(r4l(d1)+r4l(d2))); % calculated for d1
% to calculate for d2, call the function as @(p,d2,d1)

Q(1) = Qnd; % mean flow in MPA

% index of parents in the order they appear in the tree (see fig 2 in Qureshi 2018)
parents = [1,2,3,4,8,10,6,14,16,18]; 

for i=2:2:num_vessels-1
    
    d1index = i; d2index = i+1; pindex = parents(i/2);
    
    Q(d1index) = FlowCalc(Q,pindex,d1index,d2index);
    Q(d2index) = FlowCalc(Q,pindex,d2index,d1index);
    
end

% or by hand to double check the above
% for i=2:2:num_vessels-1
%     if i==2 %|| i==3
%         d1 = 2; d2 = 3; % daughter index
%         p = 1;% parent index
%         
%     elseif i==4 %|| i==5
%         d1 = 4; d2 = 5; % daughter index
%         p = 2;% parent index
%         
%     elseif i==6 %|| i==7
%         d1 = 6; d2 = 7; % daughter index
%         p = 3;% parent index
%         
%     elseif i==8 %|| i==9
%         d1 = 8; d2 = 9; % daughter index
%         p = 4;% parent index
%         
%     elseif i==10 %|| i==11
%         d1 = 10; d2 = 11; % daughter index
%         p = 8;% parent index
%         
%     elseif i==12 %|| i==13
%         d1 = 12; d2 = 13; % daughter index
%         p = 10;% parent index
%         
%     elseif i==14 %|| i==15
%         d1 = 14; d2 = 15; % daughter index
%         p = 6;% parent index
%         
%     elseif i==16 %|| i==17
%         d1 = 16; d2 = 17; % daughter index
%         p = 14;% parent index
%         
%     elseif i==18 %|| i==19
%         d1 = 18; d2 = 19; % daughter index
%         p = 16;% parent index
%         
%     elseif i==20 %|| i==21
%         d1 = 20; d2 = 21; % daughter index
%         p = 18;% parent index
%         
%     end
%     
%     Q(d1) = FlowCalc(Q,p,d1,d2);
%     Q(d2) = FlowCalc(Q,p,d2,d1);
% end

% Here, we calculate RT = P/Q, and distribute the resistance. Note that we
% set a 20/80 rule for R1/R2.

% index for the terminal vessels in the order they appear in the tree
TerminalVessels = [5,7,9,11,12,13,15,17,19,20,21];

Rtotal  = NaN(size(TerminalVessels,2),1);
R1      = NaN(size(TerminalVessels,2),1);
R2      = NaN(size(TerminalVessels,2),1);
CT      = NaN(size(TerminalVessels,2),1);

for i=1:size(TerminalVessels,2)
    Rtotal(i) = Pnd./Q(TerminalVessels(i));
    R1(i) = round(ratio.*Rtotal(i),4);
    R2(i) = round(Rtotal(i)-R1(i),4);
    CT(i) = tc./Rtotal(i);
end

%% call the model

f3 = 4*10^4; r1 = 0.2; r2 = 0.9; c = 1.5; RadSc=1; cycles=1; max_cycles = 30; id=1;
pars = [f3,r1,r2,c,RadSc,R1',R2',CT',cycles,max_cycles,id];
pars_str = mat2str(pars);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cx = unix(sprintf('./sor06  %s',pars_str(2:end-1)));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if cx == 0
    % retrieve data
    ....
else
    disp('choose new params')
end