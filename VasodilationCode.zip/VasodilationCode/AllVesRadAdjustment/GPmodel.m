function gp = GPmodel(x, y, H_r)

%% GP regression

% Hyperpriors
plg = prior_logunif();
pms = prior_logunif();
ps = prior_logunif();

for i = 1:size(H_r,1)
    lik = lik_gaussian('sigma2', H_r(end), 'sigma2_prior', ps);
    
    % We allow for different lengthscale in every dimension (ARD)
    % One magnitude as it is a 1 single output (rss 1x1)
    
    % use stationary (squared exponenetial) cov fct
    gpcf = gpcf_matern32('lengthScale', H_r(i,2:end-1), ...
        'magnSigma2', H_r(i,1),...
        'lengthScale_prior', plg, 'magnSigma2_prior', pms);
    
    % Set a small amount of jitter to be added to the diagonal elements of the
    % covariance matrix K to avoid singularities when this is inverted
    jitter=1e-8;
    
    % Create the GP structure
    gp{i} = gp_set('lik', lik, 'cf', gpcf, 'jitterSigma2', jitter);
    
    % Set the options for the optimization
    opt=optimset('TolFun',1e-6,'TolX',1e-6);
    
    % Optimize with the scaled conjugate gradient method
    [gp{i}, nlml(i)] = gp_optim(gp{i},x,y,'opt',opt);
    
end

I = find(nlml == min(nlml));
gp = gp{I};

end

