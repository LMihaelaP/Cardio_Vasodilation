clear; close all;

% Add path to GPstuff toolbox
GPpath = genpath('GPstuff-4.7'); % path including GPstuff & all folders below it
addpath(GPpath); % add the folder and its subfolders to the search path
addpath('/home/pgrad1/1106725p/TransferredFromEuclid5/For_Mihaela_NewProject/Control_LinearB_forIWSM/DilatedRadii_PostDoc/MCMC_run')
    
%% Set useful parameters
% Generic
nd = 5; % no of parameters
cycles = 1; max_cycles = 30;
ntp = 512;
t = linspace(0,0.11,ntp); t = t';
gp_ind = NaN;
em_ind = 0;
corrErr = 0;
nv = 3; % no of vessels
GP_hyperHyper = NaN(6, 1);
% ranges for [stiff, r1, r2, c, radSc]
l = [2e04, 0.05, 0.05, 0.05, 1]; % if stiffness increases, resistance is also expected to increase
u = [1e06, 2.5,  2.5,  2.5, 2];
sc = max(abs(l),abs(u));
alp = [1 1 1 1 1]; % priors
bet = [1 1 1 1 1];

% Specific
id = 10; % id for data files
extra_p = [id, nd, cycles, max_cycles];

%% Generate the data

%par_true = [2.5e+05, 1, 1.5, 0.8, 1.5]; % [stiff, r1, r2, c, RadSc]
%par_true = [51700, 0.21, 0.88, 1.44, 1.5]; % [stiff, r1, r2, c, RadSc]
par_true = [1e+05, 0.5, 1.2, 1, 1.2]; % [stiff, r1, r2, c, RadSc]

%par_true = [8e+05, 1, 1, 1, 1.5];

param = [par_true cycles, max_cycles, id];

param_str = mat2str(param);

% Calling PDEs Solver (C++)
cx = unix(sprintf('./sor06  %s',param_str(2:end-1)));

if cx == 0
    for i=1:nv % loop over vessels
        pu = load(sprintf('pu%d_%d.2d', i, id));
        [~,~,p,q,~,~] = gnuplot(pu);
        cleanHealthyPressure(ntp*(i-1)+1:ntp*i) = p(:,floor(end/2)); % clean, noiseless pressure
        cleanHealthyFlow(ntp*(i-1)+1:ntp*i) = q(:,floor(end/2)); % clean, noiseless flow
    end
    
else
    disp('..... Choose different parameter values .....')
end

figure(1); clf(1)
i=1;plot(cleanHealthyPressure(ntp*(i-1)+1:ntp*i))

truePressure = cleanHealthyPressure'; % will need to use noisy pressure
trueFlow = cleanHealthyFlow'; % will need to use noisy flow for inference

% But we only do the parameter inference on the flow data from the first 3 vessels

%% Run AM sampling

%par_start =  [8e+04, 1, 1, 0.9, 1.1];

%load('AMsimulator_Vasodil_DilatedRadii_AllPar_contd.mat');

%par_start = p_sample(i,:);

par_start = par_true;

nSamples = 150000;
n_burnin = 1000;

adapt_int = 100; % adaptation interval
scale = 1; % scale the original paramerts bc of varying mgnitudes
% proposal covariance for MH within the trajectory
cov_MH = diag(repmat(5*10^(-8),nd,1));
R = chol(cov_MH);

gp_regr_refitted = NaN; x_regr_refitted= NaN; y_regr_refitted = NaN;
gp_class = NaN; x_class = NaN; y_class = NaN; extraPar_gp = NaN; phase_ind = NaN;

p_sample = NaN(nSamples+n_burnin, nd); % unbounded HMC samples
ObjFct_sample = NaN(nSamples+n_burnin,1); % log likelihood samples
%s2_sample = NaN(nSamples+n_burnin,1); % noise variance samples
p_sample(1,:) = par_start;

qcov_adjust = 1e-8; % epsilon adjustment for chain covariance
qcov_scale = 2.4 / sqrt(nd); % s_d from recursive covariance formula
acc = 0; % acceptance rate of the algorithm
rejout = 0; % rejection rate for being outside the range

ObjFct_sample(1) = mice_pulm_ss(p_sample(1,:),trueFlow,...
    gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
    gp_class, x_class, y_class, extraPar_gp, em_ind, phase_ind, extra_p, ...
    sc, gp_ind, corrErr);

%s2_sample(1) = ObjFct_sample(1)/(ntp-nd); % observation noise variance

oldObjFct = ObjFct_sample(1);

oldpar = p_sample(1,:)./sc;

oldprior = Prior_AM(oldpar,sc,l,u,gp_ind,alp,bet,GP_hyperHyper,corrErr);

covchain = []; meanchain = []; wsum = []; lasti = 0;

s2 = 1e-06;

for i=2:nSamples+n_burnin
    
    q = randn(1,nd);
    
    newpar = oldpar + q*R;
    
    if any(newpar.*sc<l) || any(newpar.*sc>u)        
        %disp('proposal outside boundaries')
        newObjFct = 10^10; % ss
        %newObjFct = -10^10; %loglik
        
        newprior = 0;
        
        rejout = rejout + 1;
        
    else % inside the boundaries
        
        [newObjFct,pass] = Run_simulator(newpar, extra_p, trueFlow, sc, ...
            gp_ind, corrErr);
        
        newprior = Prior_AM(newpar,sc,l,u,gp_ind,alp,bet,GP_hyperHyper,corrErr);
        
    end % inside/outside boundaries
    
    if newObjFct == 10^10 % outside boundaries
        tst = 0;
    else
        tst = exp(-0.5/s2*(newObjFct - oldObjFct) + newprior-oldprior); % for ss
        %tst = exp(newObjFct - oldObjFct + newprior-oldprior); % for loglik
    end
    
    %tst 
    %
    %[newObjFct, oldObjFct]
    
    if tst <= 0
        accept = 0;
    elseif tst >= 1
        accept = 1; acc = acc + 1;
    elseif tst > rand(1,1)
        accept = 1; acc = acc + 1;
    else
        accept = 0;
    end
    
    if accept == 1 % accept proposal
        
        p_sample(i,:) = newpar.*sc;
                
        %disp('accept')
        
        oldpar = newpar;
        
        oldObjFct = newObjFct; ObjFct_sample(i) = newObjFct;
        
        oldprior = newprior;
        
    else % reject
        p_sample(i,:) = oldpar.*sc;
        
        %disp('reject')
        
        oldpar = oldpar;
        
        oldObjFct = oldObjFct; ObjFct_sample(i) = oldObjFct;
        
        oldprior = oldprior;
        
    end
    
    if mod(i, adapt_int) == 0 % we adapt
        %disp('we adapt')
        if scale == 1 % calculate the chain covariance for the transformed parameters
            [covchain,meanchain,wsum] = covupd(p_sample((lasti+1):i,1:nd)./sc,1, ...
                covchain,meanchain,wsum);
        else
            [covchain,meanchain,wsum] = covupd(p_sample((lasti+1):i,1:nd),1, ...
                covchain,meanchain,wsum);
        end
        
        upcov = covchain; % update covariance based on past samples
        
        [Ra,p] = chol(upcov);
        if p % singular
            % try to blow it
            [Ra,p] = chol(upcov + eye(nd)*qcov_adjust);
            if p == 0 % choleski decomposition worked
                % scale R
                R = Ra * qcov_scale;
            end
        else
            R = Ra * qcov_scale;
        end
        
        lasti = i;
        
    end
    
    %s2_sample(i) = 1/gamrnd(a_noisevar+0.5*ntp, 1/(b_noisevar+0.5*ObjFct_sample(i)));

    if mod(i,100) == 0
        save('AMsimulator_Vasodil_DilatedRadii_AllPar.mat');
    end
    
end

exit;