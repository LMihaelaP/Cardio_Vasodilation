% plotting routine to produce results reported in the paper

% input space
clear; close all
addpath('CommonFunctions')

cd('AllVesRadAdjustment')

load('AMsimulator_Vasodil_DilatedRadii_AllPar.mat')

parnames = {'stiffness', 'r_1', 'r_2', 'c', 'vasodilation effect'};

figure(101); clf(101)
for j=1:nd
[f, x] = ksdensity(p_sample(10000:i,j));
subplot(3,2,j);plot(x,f,'LineWidth',3);hold on
xlabel(parnames(j));set(gca, 'FontSize',20);axis tight;
end

clear

cd('TermVesRadAdjustment')

load('AMsimulator_Vasodil_DilatedRadii_AllPar.mat')

parnames = {'stiffness', 'r_1', 'r_2', 'c', 'vasodilation effect'};

figure(101); hold on
for j=1:nd
[f, x] = ksdensity(p_sample(10000:i,j));
subplot(3,2,j);hold on; plot(x,f,'LineWidth',3);
hold on; line([par_true(j) par_true(j)],ylim, 'Color', 'black', 'LineWidth',3)
xlim([l(j) u(j)])
xlabel(parnames(j));set(gca, 'FontSize',20);axis tight;
end
legend('Radius Scaling - all vessels', 'Radius Scaling - terminal vessels')


%%
%
% output space

clear

cd('AllVesRadAdjustment')
load('AMsimulator_Vasodil_DilatedRadii_AllPar.mat')

parChain = p_sample(10001:i, 1:nd);

M = size(parChain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat = parChain(fix(linspace(1, M, S)),:);

s = [];

id = 100;

nv = 3;

Pressure = NaN(S,ntp*nv);
Flow = NaN(S,ntp*nv);
Area = NaN(S,ntp*nv);

parfor s = 1:S
    
    param = [param_mat(s,:), cycles, max_cycles, id+s*100];
    
    param_str = mat2str(param);
    
    % Calling PDEs Solver (C++)
    cx = unix(sprintf('./sor06  %s',param_str(2:end-1)))
    
    for j=1:nv % loop over vessels
        pu = load(sprintf('pu%d_%d.2d', j, id+s*100));
        [~,~,p,q,A,~] = gnuplot(pu);
%         if j~=1
            pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
            flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
            area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
%         else
%             pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
%             flow(ntp*(j-1)+1:ntp*j) = q(:,1);
%             area(ntp*(j-1)+1:ntp*j) = A(:,1);
%         end
    end
    
    pressure = pressure';     flow = flow';     area = area';
    
    
    Pressure(s,:) = pressure;     Flow(s,:) = flow;     Area(s,:) = area;
    
end

AllPressures{1} = Pressure;  AllFlows{1} = Flow;

cleanHealthyFlow1 = cleanHealthyFlow;
cleanHealthyPressure1 = cleanHealthyPressure;

Y = quantile(AllPressures{1},[0.025 0.5 0.975],1); % for each row

figure(1); clf(1)

for j=1:nv
    
    subplot(3,3,3*j-2)
    
    %if j==1
        plot(linspace(0,0.11,512),cleanHealthyPressure1(ntp*(j-1)+1:ntp*j),'LineWidth',3, 'Color', 'k')
    %end
    hold on
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--r','LineWidth',3)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-g','LineWidth',3)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-g','LineWidth',3)
    
    if j==1
        legend('True MPA', 'Generated (median)', '95% CI')
    elseif j==2
        legend('True daughter 1', 'Generated (median)', '95% CI')
    else
        legend('True daughter 2', 'Generated (median)', '95% CI')
    end
    
    %if j~=1
    %    set(gca, 'XTickLabel', '', 'YTickLabel', '')
    %end
    
    xlabel('Time (s)'); ylabel('Pressure (mmHg)')
    axis tight; grid on
    ylim([min(min(cleanHealthyPressure1-1)) max(max(cleanHealthyPressure1+8)) ])
    set(gca, 'FontSize',15)
    
    title('Radius scaling -- all vessels')
    
end

%
%

cd('TermVesRadAdjustment')
load('TermVesRadAdjustment/AMsimulator_Vasodil_DilatedRadii_AllPar.mat')

parChain = p_sample(10001:i, 1:nd);

M = size(parChain, 1); % no of chain iterations

S = 100; % no of MCMC samples to use for creating the uncertainty bounds

param_mat = parChain(fix(linspace(1, M, S)),:);

% delete(gcp('nocreate'))
% parpool('local', 20)

s = [];

id = 100;

nv = 3;

Pressure = NaN(S,ntp*nv);
Flow = NaN(S,ntp*nv);
Area = NaN(S,ntp*nv);

parfor s = 1:S
    
    param = [param_mat(s,:), cycles, max_cycles, id+s*100];
    
    param_str = mat2str(param);
    
    % Calling PDEs Solver (C++)
    cx = unix(sprintf('./sor06  %s',param_str(2:end-1)))
    
    for j=1:nv % loop over vessels
        pu = load(sprintf('pu%d_%d.2d', j, id+s*100));
        [~,~,p,q,A,~] = gnuplot(pu);
        %if j~=1
            pressure(ntp*(j-1)+1:ntp*j) = p(:,floor(end/2));
            flow(ntp*(j-1)+1:ntp*j) = q(:,floor(end/2));
            area(ntp*(j-1)+1:ntp*j) = A(:,floor(end/2));
%         else
%             pressure(ntp*(j-1)+1:ntp*j) = p(:,1);
%             flow(ntp*(j-1)+1:ntp*j) = q(:,1);
%             area(ntp*(j-1)+1:ntp*j) = A(:,1);
%         end
    end
    
    pressure = pressure';     flow = flow';     area = area';
    
    
    Pressure(s,:) = pressure;     Flow(s,:) = flow;     Area(s,:) = area;
    
end

AllPressures{2} = Pressure;  AllFlows{2} = Flow;

cleanHealthyFlow2 = cleanHealthyFlow;
cleanHealthyPressure2 = cleanHealthyPressure;

Y = quantile(AllPressures{2},[0.025 0.5 0.975],1); % for each row

figure(1); hold on

for j=1:nv
        
    subplot(3,3,3*j-1)
    
    %if j==1
        plot(linspace(0,0.11,512),cleanHealthyPressure2(ntp*(j-1)+1:ntp*j),'LineWidth',3, 'Color', 'k')
    %end
    hold on
    plot(linspace(0,0.11,512), Y(2,ntp*(j-1)+1:ntp*j), '--r','LineWidth',3)
    plot(linspace(0,0.11,512), Y(1,ntp*(j-1)+1:ntp*j), '-g','LineWidth',3)
    plot(linspace(0,0.11,512), Y(3,ntp*(j-1)+1:ntp*j), '-g','LineWidth',3)
    
%     if j==1
%         legend('True MPA', 'Generated (median)', '95% CI')
%     elseif j==2
%         legend('True daughter 1', 'Generated (median)', '95% CI')
%     else
%         legend('True daughter 2', 'Generated (median)', '95% CI')
%     end
    
    %if j~=1
    %    set(gca, 'XTickLabel', '', 'YTickLabel', '')
    %end
    
    xlabel('Time (s)'); ylabel('Pressure (mmHg)')
    axis tight; grid on
    ylim([min(min(cleanHealthyPressure1-1)) max(max(cleanHealthyPressure1+8)) ])
    set(gca, 'FontSize',15)
    
    title('Radius scaling -- terminal vessels')
    
end
